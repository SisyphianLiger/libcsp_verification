# Continuous Integration

libcsp uses GitHub Actions for continuous integration:
https://github.com/libcsp/libcsp/actions
