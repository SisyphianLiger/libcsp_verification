

// Use POSIX implementation
#include "../posix/csp_clock.c"
